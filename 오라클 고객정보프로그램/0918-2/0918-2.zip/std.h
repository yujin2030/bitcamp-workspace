//std.h

#include <Windows.h>
#include <commctrl.h>
#include <vector>
#include <tchar.h>
#include <psapi.h>
#include <stdio.h>    
using namespace std;

//#include "resource.h"
#include "resource1.h"

#include "data.h"
#include "ui.h"
#include "handler.h"
#include "wbdb.h"