//data.h

typedef struct tagTeam
{
	int team_id;
	TCHAR team_name[20];
}TEAM;

typedef struct tagcustmg
{
	int id;
	TCHAR name[10];
	TCHAR phone[20];
	TCHAR register_1[20];
	TCHAR gender[2];
}custmg;