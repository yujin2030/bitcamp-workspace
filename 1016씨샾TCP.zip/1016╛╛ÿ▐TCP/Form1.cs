﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1016씨샾TCP
{
    public partial class Form1 : Form
    {
        Form2 dlg = null;
        wbClient client = new wbClient();
        public Form1()
        {
            InitializeComponent();
            client.parent(this);
        }

        private void 프로그램종료ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 서버연결ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dlg =  new Form2();
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                //dlg.IP;
                //dlg.Port;
                if(client.Connect(dlg.IP, dlg.Port) ==true)
                {
                    Ui.FillDrawing(panel1, Color.Blue);
                    Ui.LabelState(label1, true);

                    String temp = String.Format("[연결]{0}:{1} 성공", dlg.IP, dlg.Port);
                    Ui.LogPrint(listBox1, temp);
                }
                else
                {
                    String temp = String.Format("[연결]{0}:{1} 실패", dlg.IP, dlg.Port);
                    Ui.LogPrint(listBox1, temp);
                }
            }
        }

        private void 서버연결해제ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            client.DisConnect();

            Ui.FillDrawing(panel1, Color.Red);
            Ui.LabelState(label1, false);

            String temp = String.Format("[접속해제]{0}:{1} 성공", dlg.IP, dlg.Port);
            Ui.LogPrint(listBox1, temp);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string msg = string.Format("[{0}] {1}", textBox1.Text, textBox2.Text);
            client.SendMessage(msg);         
        }

        public void Print(string msg)
        {
            Ui.DataPrint(listBox2, msg);
        }
    }
}
