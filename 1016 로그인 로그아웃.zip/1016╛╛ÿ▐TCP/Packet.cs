﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1016씨샾TCP
{
    class Packet
    {
                   
        #region 싱글톤패턴
        
        public static Packet Instance { get; private set; }

        static Packet()
        {
            Instance = new Packet();
        }

        private Packet()
        {


        }
           #endregion

        public string GetNewMember(string id, string pw, string name, int age)
        {
            string msg = null;
            msg += "NEWMEMBER@";         // 회원 가입 요청 메시지
            msg += id + "#";                  // 아이디
            msg += pw + "#";                 // 암호
            msg += name + "#";                // 이름
            msg += age;         // 나이


            // 메신저 서버에 문자열 전송
            return msg;
        }

        public string GetLogin(string id, string pw)
        {
            string msg = null;
            msg += "GETLOGIN@";
            msg += id + "#";                  // 아이디
            msg += pw;                 // 암호

            return msg;
        }

        public string DelMember(string id)
        {
            string msg = null;
            msg += "DELMEMBER@";
            msg += id;                  // 아이디

            return msg;
        }

        public string GetLogout(string id)
        {
            string msg = null;
            msg += "GETLOGOUT@";
            msg += id;                  // 아이디

            return msg;
        }

        public string GetMessage(string msg1)
        {
            string msg = null;
            msg += "GETMESSAGE@";
            msg += msg1;                  // 아이디

            return msg;
        }
    }
}
