﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1016씨샾TCP
{
    public partial class Form1 : Form
    {
        Form2 dlg = null;
        Form3 frm3 = null;

        wbClient client = new wbClient();
        public Form1()
        {
            InitializeComponent();
            client.parent(this);
        }

        private void 프로그램종료ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 서버연결ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dlg =  new Form2();
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                //dlg.IP;
                //dlg.Port;
                if(client.Connect(dlg.IP, dlg.Port) ==true)
                {
                    Ui.FillDrawing(panel1, Color.Blue);
                    Ui.LabelState(label1, true);

                    String temp = String.Format("[연결]{0}:{1} 성공", dlg.IP, dlg.Port);
                    Ui.LogPrint(listBox1, temp);
                }
                else
                {
                    String temp = String.Format("[연결]{0}:{1} 실패", dlg.IP, dlg.Port);
                    Ui.LogPrint(listBox1, temp);
                }
            }
        }

        private void 서버연결해제ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            client.DisConnect();

            Ui.FillDrawing(panel1, Color.Red);
            Ui.LabelState(label1, false);

            String temp = String.Format("[접속해제]{0}:{1} 성공", dlg.IP, dlg.Port);
            Ui.LogPrint(listBox1, temp);
        }

        private void 회원가입ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm3 = new Form3();
            if (frm3.ShowDialog() == DialogResult.OK)
            {
                string msg;
                msg = Packet.Instance.GetNewMember(frm3.Id, frm3.Pw, frm3.Name, frm3.Age);
                client.SendMessage(msg);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string msg = string.Format(" {0}", textBox2.Text);
            string msg;
            msg = Packet.Instance.GetMessage(textBox2.Text);

            client.SendMessage(msg);         
        }

        public void Print(string msg)
        {
            Ui.DataPrint(listBox2, msg);
        }

        private void button2_Click(object sender, EventArgs e)    //로그인
        {
            string msg;
            msg = Packet.Instance.GetLogin(textBox1.Text, textBox3.Text);
            client.SendMessage(msg);
        }

        private void button3_Click(object sender, EventArgs e) //로그아웃
        {
            string msg;
            msg = Packet.Instance.GetLogout(textBox1.Text);
            client.SendMessage(msg);
        }

        private void button4_Click(object sender, EventArgs e)    //삭제
        {
            string msg;
            msg = Packet.Instance.DelMember(textBox1.Text);
            client.SendMessage(msg);
        }
    }
}
