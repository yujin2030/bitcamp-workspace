﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1016Server
{
    class Packet
    {
        #region 싱글톤 패턴
        public static Packet Instance { get; private set; }

        static Packet()
        {
            Instance = new Packet();
        }

        private Packet()
        {

        }
        #endregion 

        public string GetNewMember(string id, string pw, string name, int age)
        {
            string msg = null;
            msg += "NEW_MEMBER@";         // 회원 가입 요청 메시지
            msg += id + "#";              // 아이디
            msg += pw + "#";              // 암호
            msg += name + "#";            // 이름
            msg += age + "#";             // 나이     
            return msg;
        }
    }
}
