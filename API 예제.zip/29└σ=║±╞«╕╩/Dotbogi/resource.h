//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Dotbogi.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       103
#define ID_MENU_1X                      40001
#define ID_MENU_2X                      40002
#define ID_MENU_3X                      40003
#define ID_MENU_4X                      40004
#define ID_MENU_5X                      40005
#define ID_MENU_10X                     40006
#define ID_MENU_HELP                    40007
#define ID_MENU_EXIT                    40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
