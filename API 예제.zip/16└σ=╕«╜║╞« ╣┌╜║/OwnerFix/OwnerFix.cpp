#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("OwnerFix");

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

void DrawBitmap(HDC hdc,int x,int y,HBITMAP hBit)
{
	HDC MemDC;
	HBITMAP OldBitmap;
	int bx,by;
	BITMAP bit;

	MemDC=CreateCompatibleDC(hdc);
	OldBitmap=(HBITMAP)SelectObject(MemDC, hBit);

	GetObject(hBit,sizeof(BITMAP),&bit);
	bx=bit.bmWidth;
	by=bit.bmHeight;

	BitBlt(hdc,x,y,bx,by,MemDC,0,0,SRCCOPY);

	SelectObject(MemDC,OldBitmap);
	DeleteDC(MemDC);
}

#include "resource.h"
#define ID_LISTBOX 100
HWND hList;
HBITMAP hbmp1, hbmp2, hbmp3;
LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	LPMEASUREITEMSTRUCT lpmis;
	LPDRAWITEMSTRUCT lpdis;
	HBITMAP hbmp;
	HBRUSH bkBrush;
	switch (iMessage) {
	case WM_CREATE:
		// ���� ��ο� ����Ʈ �ڽ��� �����.
		hList=CreateWindow(TEXT("listbox"),NULL,WS_CHILD | WS_VISIBLE | WS_BORDER |
			WS_VSCROLL | LBS_NOTIFY | LBS_OWNERDRAWFIXED,
			10,10,110,200,hWnd,(HMENU)ID_LISTBOX,g_hInst,NULL);

		// ��Ʈ�� �� ���� �о�´�.
		hbmp1=LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		hbmp2=LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP2));
		hbmp3=LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP3));

		// �׸� �� ���� �߰��ϰ� �׸� �����Ϳ� ��Ʈ�� �ڵ��� ����Ѵ�.
		SendMessage(hList,LB_ADDSTRING,0,(LPARAM)hbmp1);
		SendMessage(hList,LB_ADDSTRING,0,(LPARAM)hbmp2);
		SendMessage(hList,LB_ADDSTRING,0,(LPARAM)hbmp3);
		return 0;
	case WM_MEASUREITEM:
		// �� �׸��� ���̴� 24�ȼ��̴�.
		lpmis=(LPMEASUREITEMSTRUCT)lParam;
		lpmis->itemHeight=24;
		return TRUE;
	case WM_DRAWITEM:
		lpdis=(LPDRAWITEMSTRUCT)lParam;

		// ���� ��Ȳ�� ���� �Ķ��� ����� ����Ѵ�.
		if (lpdis->itemState & ODS_SELECTED) {
			bkBrush=GetSysColorBrush(COLOR_HIGHLIGHT);
		} else {
			bkBrush=GetSysColorBrush(COLOR_WINDOW);
		}
		FillRect(lpdis->hDC,&lpdis->rcItem,bkBrush);

		// �׸� �����ͷκ��� ��Ʈ�� �ڵ��� �о� ����Ѵ�.
		hbmp=(HBITMAP)lpdis->itemData;
		DrawBitmap(lpdis->hDC,lpdis->rcItem.left+5,lpdis->rcItem.top+2,hbmp);
		return TRUE;
	case WM_DESTROY:
		DeleteObject(hbmp1);
		DeleteObject(hbmp2);
		DeleteObject(hbmp3);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
