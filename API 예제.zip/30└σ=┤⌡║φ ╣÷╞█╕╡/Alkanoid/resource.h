//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Alkanoid.rc
//
#define IDB_WALL                        101
#define IDB_BRICK1                      102
#define IDB_BALL                        103
#define IDB_STICK                       104
#define IDB_RACKETSMALL                 104
#define IDB_BRICK2                      105
#define IDB_BRICK3                      106
#define IDR_WAVE1                       107
#define IDR_WAVE2                       108
#define IDR_WAVE3                       109
#define IDB_RACKETMID                   110
#define IDB_RACKETBIG                   111
#define IDB_BACKGROUND                  112
#define IDR_WAVE4                       113
#define IDR_WAVE5                       114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
