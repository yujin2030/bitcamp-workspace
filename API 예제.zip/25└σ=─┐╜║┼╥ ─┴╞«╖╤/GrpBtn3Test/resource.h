//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GrpBtn3Test.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GRPBTNTYPE                  129
#define IDB_BTN1NORMAL                  130
#define IDB_BTN1HOT                     131
#define IDB_BTN1DOWN                    132
#define IDB_BTN1DISABLE                 133
#define IDB_BTN3NORMAL                  134
#define IDB_BTN2DISABLE                 135
#define IDB_BTN2DOWN                    136
#define IDB_BTN2HOT                     137
#define IDB_BTN2NORMAL                  138
#define IDB_BTN3DOWN                    139

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
