// GrpBtn3TestDoc.h : interface of the CGrpBtn3TestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRPBTN3TESTDOC_H__915721C2_EE89_4B4C_B55B_E70E59D44B17__INCLUDED_)
#define AFX_GRPBTN3TESTDOC_H__915721C2_EE89_4B4C_B55B_E70E59D44B17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGrpBtn3TestDoc : public CDocument
{
protected: // create from serialization only
	CGrpBtn3TestDoc();
	DECLARE_DYNCREATE(CGrpBtn3TestDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGrpBtn3TestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGrpBtn3TestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGrpBtn3TestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRPBTN3TESTDOC_H__915721C2_EE89_4B4C_B55B_E70E59D44B17__INCLUDED_)
