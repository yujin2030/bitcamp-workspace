//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GrpBtn2Test.rc
//
#define IDB_BTN1NORMAL                  101
#define IDB_BTN1HOT                     102
#define IDB_BTN1DOWN                    103
#define IDB_BTN1DISABLE                 104
#define IDB_BTN2NORMAL                  105
#define IDB_BTN2HOT                     106
#define IDB_BTN2DOWN                    107
#define IDB_BTN2DISABLE                 108
#define IDB_BTN3NORMAL                  109
#define IDB_BTN3DOWN                    110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
