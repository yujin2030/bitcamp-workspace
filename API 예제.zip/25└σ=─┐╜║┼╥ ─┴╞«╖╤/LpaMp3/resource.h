//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LpaMp3.rc
//
#define IDB_PLAYNORMAL                  101
#define IDB_PLAYHOT                     102
#define IDB_PLAYDOWN                    103
#define IDB_CLOSENORMAL                 104
#define IDB_CLOSEDOWN                   105
#define IDB_CLOSEHOT                    106
#define IDB_OPENDOWN                    107
#define IDB_OPENHOT                     108
#define IDB_OPENNORMAL                  109
#define IDB_STOPNORMAL                  113
#define IDB_PREVNORMAL                  114
#define IDB_NEXTNORMAL                  115
#define IDB_ATOPNORMAL                  116
#define IDB_REPEATNORMAL                117
#define IDB_PLISTNORMAL                 118
#define IDB_ATOPDOWN                    119
#define IDB_REPEATDOWN                  120
#define IDB_PLISTDOWN                   121
#define IDB_MINNORMAL                   122
#define IDB_MINDOWN                     123
#define IDB_MINHOT                      124
#define IDB_ATOPHOT                     125
#define IDB_NEXTHOT                     126
#define IDB_NEXTDOWN                    127
#define IDB_PREVHOT                     128
#define IDB_PREVDOWN                    129
#define IDB_STOPHOT                     130
#define IDB_STOPDOWN                    131
#define IDB_MENUNORMAL                  132
#define IDB_MENUDOWN                    133
#define IDB_MENUHOT                     134
#define IDR_MENU1                       135
#define IDI_ICON1                       136
#define IDM_POPUP_REPSEQ                40001
#define IDM_POPUP_REPONE                40002
#define IDM_POPUP_REPALL                40003
#define IDM_POPUP_RANDOM                40004
#define IDM_POPUP_ATOP                  40005
#define IDM_POPUP_SPECTRUM              40006
#define IDM_POPUP_EXT                   40007
#define IDM_POPUP_ABOUT                 40008
#define IDM_POPUP_REMAKE                40009
#define IDM_POPUP_ADDLIST               40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
