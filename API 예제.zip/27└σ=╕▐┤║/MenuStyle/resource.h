//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuStyle.rc
//
#define IDR_MENU1                       101
#define ID_NORMAL                       40001
#define ID_CHECKED                      40002
#define ID_GRAYED                       40003
#define ID_INACTIVE                     40004
#define ID_POPUPITEM1                   40005
#define ID_POPUPITEM2                   40006
#define ID_POPUPITEM3                   40007
#define ID_HELP_ABOUT                   40008
#define ID_MENUITEM40009                40009
#define ID_MENUITEM40010                40010
#define ID_MENUITEM40011                40011
#define ID_MENUITEM40012                40012
#define ID_MENUITEM40013                40013
#define ID_MENUITEM40014                40014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
