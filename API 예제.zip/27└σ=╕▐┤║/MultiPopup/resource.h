//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultiPopup.rc
//
#define IDR_MENU1                       101
#define ID_CHINA_JJAJJANG               40001
#define ID_CHINA_JJAMBBONG              40002
#define ID_CHINA_TANGSOOYOOK            40003
#define ID_CHINA_BBOK                   40004
#define ID_CHINA_JABCHAEBAB             40005
#define ID_CHINA_GUNMANDOO              40006
#define ID_PIZZA_COMBINATION            40007
#define ID_PIZZA_POTATO                 40008
#define ID_PIZZA_BULGALBI               40009
#define ID_CHICKEN_FRIED                40010
#define ID_CHICKEN_YANGNYUM             40011
#define ID_CHICKEN_DAKBAL               40012
#define ID_CHICKEN_ORIBAL               40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
