BOOL XCopy(LPCTSTR Src, LPCTSTR Dest);
void CenterWindow(HWND hWnd);
BOOL BrowseFolder(HWND hParent, LPCTSTR szTitle, LPCTSTR StartPath, TCHAR *szFolder);

