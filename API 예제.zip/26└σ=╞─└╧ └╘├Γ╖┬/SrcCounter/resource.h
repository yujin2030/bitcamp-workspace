//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SrcCounter.rc
//
#define IDD_DIALOG1                     101
#define IDD_DLGMAIN                     101
#define IDI_ICON1                       103
#define IDD_DLGBACK                     104
#define IDD_DLGREGFOLDER                105
#define IDC_LIST_SRC                    1000
#define IDC_BTN_COUNT                   1009
#define IDC_CBPRJTYPE                   1010
#define IDC_EXTENSION                   1011
#define IDC_EDIT_DIR                    1013
#define IDC_BTN_BROWSE                  1014
#define IDC_LIST1                       1015
#define IDC_RESULT                      1016
#define IDC_REGFOLDER                   1017
#define IDC_PRJFOLDER                   1017
#define IDC_REGISTER                    1018
#define IDC_BACKUP                      1019
#define IDC_EDEDITOR                    1020
#define IDC_BTNSETEDIT                  1021
#define IDC_EDSRC                       1022
#define IDC_EDDEST                      1023
#define IDC_BTNBROWSE                   1024
#define IDC_EDEXFOLDER                  1027
#define IDC_EDEXFILE                    1028
#define IDC_STATUS                      1029
#define IDC_BTNADD                      1030
#define IDC_BTNDEL                      1031
#define IDC_LISTFOLDER                  1032
#define IDC_EDFIND                      1033
#define IDC_BTNFIND                     1034
#define IDC_BTN_LIST                    1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
