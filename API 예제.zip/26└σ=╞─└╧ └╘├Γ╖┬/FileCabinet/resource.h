//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileCabinet.rc
//
#define IDB_TREEIMAGE                   102
#define IDR_MENU1                       103
#define IDD_ADDVOLUME                   104
#define IDD_DLGNEWCAB                   106
#define IDR_POPUP                       107
#define IDI_ICON1                       108
#define IDD_DLGREMARK                   109
#define IDD_DLGPASS                     110
#define IDD_DLGABOUT                    111
#define IDB_TOOLBAR                     301
#define IDC_BTNBROWSE                   1000
#define IDC_EDFOLDER                    1004
#define IDC_EDCABNAME                   1006
#define IDC_EDCABDESC                   1008
#define IDC_CHKINCHID                   1008
#define IDC_CHKZIPDIR                   1009
#define IDC_CHKMAKEPREVIEW              1010
#define IDC_EDTITLE                     1011
#define IDC_EDDESC                      1012
#define IDC_DRIVES                      1013
#define IDC_EDREMARK                    1015
#define IDC_CHKCOMP                     1016
#define IDC_CHKENCRYPT                  1017
#define IDC_EDPASSWORD                  1018
#define IDNOOK                          1021
#define IDM_FILE_EXIT                   40008
#define IDM_CAB_CLOSE                   40014
#define IDM_CAB_EDIT                    40015
#define IDM_VOL_REMAKE                  40016
#define IDM_REC_DELETE                  40017
#define IDM_VOL_DELETE                  40019
#define IDM_CAB_ADDVOL                  40020
#define IDM_CAB_SAVE                    40021
#define IDM_EMPTY_NEWCABINET            40022
#define IDM_EMPTY_OPENCABINET           40023
#define IDM_CAB_SAVEAS                  40024
#define IDM_EMPTY_SAVEALL               40025
#define IDM_EMPTY_CLOSEALL              40026
#define IDM_HELP_ABOUT                  40027
#define ID_MENUITEM40028                40028
#define ID_MENUITEM40029                40029
#define ID_MENUITEM40030                40030
#define ID_MENUITEM40031                40031
#define ID_MENUITEM40032                40032
#define ID_MENUITEM40033                40033
#define ID_MENUITEM40034                40034
#define ID_MENUITEM40035                40035
#define ID_MENUITEM40036                40036
#define ID_MENUITEM40037                40037
#define ID_MENUITEM40038                40038
#define ID_MENUITEM40039                40039
#define ID_MENUITEM40040                40040
#define ID_MENUITEM40041                40041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40042
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
