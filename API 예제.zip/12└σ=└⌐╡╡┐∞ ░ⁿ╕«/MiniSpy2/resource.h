//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MiniSpy.rc
//
#define IDI_ICON1                       101
#define IDR_MENU1                       102
#define IDD_DIALOG1                     103
#define IDM_EXIT                        40001
#define IDM_TOP                         40002
#define IDM_ABOUT                       40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
